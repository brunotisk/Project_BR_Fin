import type { Database } from './database'

type Tabelas = Database['public']['Tables']

export type Linha<T extends keyof Tabelas> = Tabelas[T]['Row']
export type NovaLinha<T extends keyof Tabelas> = Tabelas[T]['Insert']
export type Atualizacao<T extends keyof Tabelas> = Tabelas[T]['Update']

// Valores aceitos pelos CHECKs do banco (o banco guarda como text).
export type TipoTransacao = 'receita' | 'despesa'
export type StatusTransacao = 'pendente' | 'confirmado' | 'cancelado'
export type TipoConta = 'corrente' | 'poupanca' | 'carteira' | 'investimento' | 'outro'
export type StatusParcela = 'pendente' | 'paga' | 'cancelada'
export type StatusMeta = 'ativa' | 'concluida' | 'cancelada'

export type Perfil = Linha<'profiles'>
export type Categoria = Omit<Linha<'categorias'>, 'tipo'> & { tipo: TipoTransacao }
export type Conta = Omit<Linha<'contas'>, 'tipo'> & { tipo: TipoConta }
export type Transacao = Omit<Linha<'transacoes'>, 'tipo' | 'status'> & {
  tipo: TipoTransacao
  status: StatusTransacao
}
export type Parcela = Omit<Linha<'parcelas'>, 'status'> & { status: StatusParcela }
export type Meta = Omit<Linha<'metas'>, 'status'> & { status: StatusMeta }
export type Orcamento = Linha<'orcamentos'>

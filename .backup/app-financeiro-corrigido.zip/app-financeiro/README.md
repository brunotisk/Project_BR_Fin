# App Financeiro

Aplicativo mobile-first para controle financeiro pessoal/SaaS, com React Native + Expo (SDK 57) + TypeScript + Supabase.

## Estrutura

- `src/screens`: telas
- `src/components`: componentes reutilizáveis
- `src/services`: Supabase e autenticação
- `src/navigation`: navegação (React Navigation)
- `src/types`: tipos compartilhados (`database.ts` = tipos do banco)
- `src/utils`: utilitários (`notify` funciona em mobile e Web)
- `src/theme`: identidade visual
- `supabase/migrations`: banco versionado

## Criar o ambiente

1. Tenha Node.js LTS instalado.
2. Copie `.env.example` para `.env`.
3. Preencha `EXPO_PUBLIC_SUPABASE_URL` e `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY` com os dados do projeto Supabase
   (Project Settings → API). Use apenas a chave **publicável**; nunca coloque a `secret`/`service_role` no app.
4. Instale as dependências:

```bash
npm install
npx expo install --check   # confirma que as versões batem com o SDK
npx expo-doctor            # diagnóstico geral do projeto
```

## Rodar

```bash
npm run start
```

Depois use Expo Go, Android, iOS ou Web. Se mudar o `.env`, reinicie com `npx expo start -c`.

## Banco de dados (Supabase CLI)

```bash
npx supabase init                      # só na primeira vez (cria supabase/config.toml)
npx supabase login
npx supabase link --project-ref SEU_PROJECT_REF
npx supabase db push                   # aplica as migrations em supabase/migrations
```

Depois de aplicar as migrations, gere os tipos do banco:

```bash
npx supabase gen types typescript --linked > src/types/database.ts
```

> Não edite migrations já aplicadas. Mudanças no banco entram como uma nova migration (`0003_...`, `0004_...`).

## Autenticação

- Sessão persistida via `expo-sqlite/localStorage`.
- O token é renovado só com o app em primeiro plano (`AppState` em `src/services/supabase.ts`).
- Um trigger (`0002_...`) cria a linha em `profiles` automaticamente a cada novo usuário.

## Próxima etapa

Definir o modelo de dados financeiro (contas, categorias, transações) antes de criar as tabelas de negócio.
Pontos a decidir antes: valores em `numeric(12,2)` ou centavos inteiros, e se haverá contas compartilhadas
(isso muda o desenho do RLS).

/**
 * Tipos do banco, escritos à mão só para a tabela `profiles`.
 *
 * Quando o projeto Supabase estiver linkado, substitua este arquivo pelo gerado:
 *   npx supabase gen types typescript --linked > src/types/database.ts
 */
export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: { id: string; created_at: string }
        Insert: { id: string; created_at?: string }
        Update: { id?: string; created_at?: string }
        Relationships: []
      }
    }
    Views: { [_ in never]: never }
    Functions: { [_ in never]: never }
    Enums: { [_ in never]: never }
    CompositeTypes: { [_ in never]: never }
  }
}

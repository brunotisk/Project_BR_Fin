export type Expense = {
  id: string
  description: string
  amount: number
  date: string
  categoryId?: string
}

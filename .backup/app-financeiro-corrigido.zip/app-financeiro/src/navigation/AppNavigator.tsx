import { ActivityIndicator, View } from 'react-native'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { useAuth } from '../services/AuthProvider'
import { LoginScreen } from '../screens/LoginScreen'
import { HomeScreen } from '../screens/HomeScreen'
import { colors } from '../theme'

export type RootStackParamList = {
  Login: undefined
  Home: undefined
}

const Stack = createNativeStackNavigator<RootStackParamList>()

export function AppNavigator() {
  const { session, loading } = useAuth()

  if (loading) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background }}>
        <ActivityIndicator size="large" />
      </View>
    )
  }

  return (
    <Stack.Navigator>
      {session ? (
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Início' }} />
      ) : (
        <Stack.Screen name="Login" component={LoginScreen} options={{ title: 'Entrar' }} />
      )}
    </Stack.Navigator>
  )
}

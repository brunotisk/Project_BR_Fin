import { useState } from 'react'
import { KeyboardAvoidingView, Platform, StyleSheet, Text, TextInput, View } from 'react-native'
import { Button } from '../components/Button'
import { useAuth } from '../services/AuthProvider'
import { colors } from '../theme'
import { notify } from '../utils/notify'

const MIN_PASSWORD_LENGTH = 6

export function LoginScreen() {
  const { signIn, signUp } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  function validate() {
    if (!email.trim() || !password) {
      notify('Atenção', 'Informe e-mail e senha.')
      return false
    }
    return true
  }

  async function handleSignIn() {
    if (!validate()) return
    setLoading(true)
    const { error } = await signIn(email.trim(), password)
    setLoading(false)
    if (error) notify('Não foi possível entrar', error.message)
  }

  async function handleSignUp() {
    if (!validate()) return
    if (password.length < MIN_PASSWORD_LENGTH) {
      notify('Senha curta', `Use pelo menos ${MIN_PASSWORD_LENGTH} caracteres.`)
      return
    }
    setLoading(true)
    const { error } = await signUp(email.trim(), password)
    setLoading(false)
    if (error) {
      notify('Não foi possível cadastrar', error.message)
      return
    }
    notify('Cadastro', 'Conta criada. Se a confirmação por e-mail estiver habilitada, confirme seu e-mail antes de entrar.')
  }

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.content}>
        <Text style={styles.title}>App Financeiro</Text>
        <Text style={styles.subtitle}>Controle seus gastos de forma simples.</Text>

        <TextInput
          value={email}
          onChangeText={setEmail}
          placeholder="E-mail"
          placeholderTextColor={colors.muted}
          autoCapitalize="none"
          autoCorrect={false}
          autoComplete="email"
          textContentType="emailAddress"
          keyboardType="email-address"
          style={styles.input}
        />
        <TextInput
          value={password}
          onChangeText={setPassword}
          placeholder="Senha"
          placeholderTextColor={colors.muted}
          autoCapitalize="none"
          autoCorrect={false}
          autoComplete="current-password"
          textContentType="password"
          secureTextEntry
          style={styles.input}
        />

        <Button title="Entrar" onPress={handleSignIn} loading={loading} />
        <Button title="Criar conta" onPress={handleSignUp} variant="secondary" disabled={loading} />
      </View>
    </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { flex: 1, justifyContent: 'center', padding: 24, gap: 14 },
  title: { fontSize: 30, fontWeight: '700', color: colors.text },
  subtitle: { fontSize: 16, color: colors.muted, marginBottom: 18 },
  input: { borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 14, fontSize: 16, color: colors.text, backgroundColor: colors.surface }
})

import { StyleSheet, Text, View } from 'react-native'
import { Button } from '../components/Button'
import { useAuth } from '../services/AuthProvider'
import { colors } from '../theme'

export function HomeScreen() {
  const { session, signOut } = useAuth()

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Olá 👋</Text>
      <Text style={styles.subtitle}>{session?.user.email}</Text>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Seu controle financeiro começa aqui.</Text>
        <Text style={styles.cardText}>Dashboard, gastos, receitas e categorias serão adicionados nas próximas etapas.</Text>
      </View>
      <Button title="Sair" onPress={signOut} variant="secondary" />
    </View>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, backgroundColor: colors.background, gap: 16 },
  title: { fontSize: 30, fontWeight: '700', color: colors.text, marginTop: 24 },
  subtitle: { color: colors.muted },
  card: { backgroundColor: colors.surface, borderRadius: 14, borderWidth: 1, borderColor: colors.border, padding: 18, gap: 8 },
  cardTitle: { fontSize: 18, fontWeight: '600', color: colors.text },
  cardText: { color: colors.muted, lineHeight: 22 }
})
